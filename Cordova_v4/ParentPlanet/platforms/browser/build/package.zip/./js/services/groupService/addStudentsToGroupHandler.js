var AddStudentsToGroupHandler = function() {}

_inheritsFrom(AddStudentsToGroupHandler, BaseAddStudentToGroupHandler);