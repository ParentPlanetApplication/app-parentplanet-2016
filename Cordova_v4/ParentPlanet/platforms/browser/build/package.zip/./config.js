APPLICATIONID = 'C5E7FSUJXEJ7gTODpBLCuZShhJUxhu9AHjdlU4QR-AwsProduction'
SERVERURL = 'https://server.parentplanet.com:13370/parse/'
MODESERVER = 'Production'
