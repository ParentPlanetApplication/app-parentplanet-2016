APPLICATIONID='C5E7FSUJXEJ7gTODpBLCuZShhJUxhu9AHjdlU4QR'
SERVERURL='https://server.parentplanet.com:1337/parse/'
MODESERVER='Staging'